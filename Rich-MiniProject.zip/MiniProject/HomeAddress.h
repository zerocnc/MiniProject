#pragma once

class HouseAddress {
public:
	std::string HomeAddress;
private:
};