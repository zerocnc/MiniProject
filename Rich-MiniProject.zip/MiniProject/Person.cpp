#include "Person.h"

Person::Person()
{
	FirstName = "";
	LastName = "";
}

