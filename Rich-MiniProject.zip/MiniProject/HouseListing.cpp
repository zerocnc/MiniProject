#include <iostream>
#include "HouseListing.h"

HouseListing::HouseListing()
{
	HousePrice = 0;
}