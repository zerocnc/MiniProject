#include <fstream>
#include <iostream>
#include "HouseDescription.h"

HouseDescription::HouseDescription() {
	SQ_Feet(0);
	BedRoom(0);
}
