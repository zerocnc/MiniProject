#include "HouseAddress.h"

HouseAddress::HouseAddress()
{
	StreetAddress = "";
}

